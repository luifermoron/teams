export const TEAM_CLASSNAME = "team";
export const PLAYER_CLASSNAME = "players";