export default interface ITeam {
    id: number;
    name: string;
    group: string;
    coach: string;
}