export const ROUTE_VERSION_TWO: number = 2;
export const ROUTE_VERSION_ONE: number = 1;

export default {
    ROUTE_VERSION_TWO,
    ROUTE_VERSION_ONE
}