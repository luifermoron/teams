export const GET_ALL_TEAMS_SUCCES_RESPONSE_V1 = "Teams retrieved succesfully V1";
export const GET_ALL_TEAMS_SUCCES_RESPONSE_V2 = "Teams retrieved succesfully V2";


export const GET_ALL_PLAYERS_SUCCESS_RESPONSE_V1 = "Players retrieved succesfully V1";